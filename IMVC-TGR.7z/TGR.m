function [Z,F,pre_labels1,obj,R] = IMVTSC(Z_ini,X,Ne,W,lambda2,lambda3,lambda4,miu,rho,max_iter,numClust,truthF,p)
% figure;
Z = Z_ini;
P = Z;
mode = 2;
beta = ones(size(X{1},2),1);
clear Z_ini
for iv = 1:length(X)
    E{iv} = zeros(size(X{iv},1),Ne(iv));
    B{iv} = zeros(size(X{iv}));
    A{iv} = zeros(size(Z{iv}));
    C{iv} = zeros(size(X{iv}));
    D{iv} = zeros(size(Z{iv}));
    H{iv} = eye(size(Z{iv}));
end
omega = ones(iv, 1) ./ iv;
nv = length(X);
Nsamp = size(X{1},2);
R = zeros(Nsamp, Nsamp);
for iter = 1:max_iter
    Z_pre = Z;
    E_pre = E;
    B_pre = B;
    P_pre = P;
    % --------- update Z ------%
    SumZ = 0;
    SZ = 0;
    for iv = 1:nv
        SumZ = SumZ+Z{iv};
    end
    for iv = 1:nv
        Y = X{iv}+E{iv}*W{iv}';
        linshi1 = (2*lambda3*((nv-1)/nv)^2+miu+2*omega(iv))*eye(Nsamp)+miu*(Y'*Y);
        linshi2 = 2*lambda3*(nv-1)/(nv*nv)*(SumZ-Z{iv})+miu*P{iv}-A{iv}+Y'*(miu*(Y-B{iv}-Y*D{iv})+C{iv})+2*omega(iv)*R;
        linshi = linshi1\linshi2;
        Z1 = zeros(size(linshi));
        for is = 1:size(linshi,1)
           ind_c = 1:size(linshi,1);
           ind_c(is) = [];
           Z1(is,ind_c) = EProjSimplex_new(linshi(is,ind_c));
        end
        Z1(isnan(Z1)) = 0;
        Z{iv} = Z1;
        SZ = omega(iv)*Z{iv} + SZ;
    end
    %update R
    SZ = SZ ./ sum(omega);
    R = SZ - diag(diag(SZ));
    R = max(0.5 * (R + R'), 0);
    % update omega
    for v = 1 : nv
        omega(v) = 0.5 / (norm(Z{v} - R, 'fro') + eps);
    end
    clear Y linshi1 linshi2 linshi Z1 SZ 
    %----------------D------------------%
    for iv = 1:nv
        Di = sqrt(sum(D{iv}.*D{iv},2)+eps);
        d = 0.5./Di;
        H{iv} = diag(d);
        Y = X{iv}+E{iv}*W{iv}';
        t1 = 2*lambda4*H{iv}+miu*(Y'*Y);
        t2 = Y'*(miu*(Y-B{iv}-Y*Z{iv})+C{iv});
        D1 = t1\t2;
%         D1(D1<0)=1e-11;
        D1(isnan(D1)) = 0;
        D{iv} = D1;
    end
    clear t1 t2 Y
    % ----------------- P --------------%
    Z_tensor = cat(3, Z{:,:});
    A_tensor = cat(3, A{:,:});
    [P_tensor,~,~] = prox_tnn(Z_tensor+A_tensor/miu,beta/miu,p,mode);
    for iv = 1:nv
        P{iv} = P_tensor(:,:,iv);
        % -------- E{iv} B{iv} ------- %
        WWZ = W{iv}'-W{iv}'*(Z{iv}+D{iv});
        E{iv} = ((miu*(X{iv}*(Z{iv}+D{iv})+B{iv}-X{iv})-C{iv})*WWZ')/(miu*(WWZ*WWZ'));
        linshi1 = X{iv}+E{iv}*W{iv}';
        temp1 = linshi1-linshi1*(Z{iv}+D{iv})+1/miu*C{iv};
        temp2 = lambda2/miu;
        B{iv} = max(0,temp1-temp2) + min(0,temp1+temp2);
        % -------- A{iv} C{iv} ------%
        A{iv} = A{iv}+miu*(Z{iv}-P{iv});
        C{iv} = C{iv}+miu*(linshi1-linshi1*(Z{iv}+D{iv})-B{iv});
        clear temp1 temp2 linshi1 WWZ
    end
    clear Z_tensor A_tensor  P_tensor
    
    miu = min(miu*rho, 1e10);
    diff_Z = 0;
    diff_E = 0;
    diff_B = 0;
    diff_P = 0;
    leqm1  = 0;
    %% check convergence
    for iv = 1:nv
        linshi1 = X{iv}+E{iv}*W{iv}';
        normX = norm(X{iv},'fro')^2;
        Rec_error = (linshi1-linshi1*Z{iv}-B{iv})./normX;
        leqm1 = max(leqm1,max(abs(Rec_error(:))));
        diff_Z = max(diff_Z,max(abs(Z{iv}(:)-Z_pre{iv}(:))));
        diff_E = max(diff_E,max(abs(E{iv}(:)-E_pre{iv}(:))));
        diff_B = max(diff_B,max(abs(B{iv}(:)-B_pre{iv}(:))));
        diff_P = max(diff_P,max(abs(P{iv}(:)-P_pre{iv}(:)))); 
    end
    leqm2 = max(diff_P,max(diff_B,max(diff_E,diff_Z)));
    clear  leqm Rec_error_tensor Rec_error
    err = min([leqm1,leqm2]);
obj(iter) = err;

if err < 1e-6
    iter
    break
end
F = SpectralClustering(R, numClust);
    for iter_c = 1
        pre_labels1    = kmeans(real(F),numClust, 'maxiter', 100, 'replicates', 20, 'emptyaction', 'singleton');
        result_LatLRR1 = ClusteringMeasure(truthF, pre_labels1);
        AC(iter_c)    = result_LatLRR1(1)
        MIhat(iter_c) = result_LatLRR1(2);
        Purity(iter_c)= result_LatLRR1(3);
    end

end
end
