clear all
clc
load("3sources3vbigRnSp.mat");
load("3sources3vbigRnSp_percentDel_0.55.mat");
lambda1 = 1e-1;%-1
lambda2 = 1e0;%0
lambda3 = 1e1;%1
f = 7;
ind_folds = folds{f}; 
truthF = truth;
clear truth folds
numClust = length(unique(truthF));
                
for iv = 1:length(X)
    X1 = X{iv};
    X1 = NormalizeFea(X1,0);
    ind_0 = find(ind_folds(:,iv) == 0);
    ind_1 = find(ind_folds(:,iv) == 1);
    X1(:,ind_0) = 0;    % 缺失视角补0
    Y{iv} = X1;         % 一列一个样本
    % ------------- 构造缺失视角的索引矩阵 ----------- %
    linshi_W = eye(size(X1,2));
    linshi_W(:,ind_1) = [];
    W{iv} = linshi_W;
    Ne(iv) = length(ind_0); 
    % ---------- 初始KNN图构建 ----------- %
    X1(:,ind_0) = [];
    options = [];
    options.NeighborMode = 'KNN';
    options.k = 5;
    options.WeightMode = 'Binary';      % Binary  HeatKernel
    Z1 = full(constructW(X1',options));

    linshi_W = diag(ind_folds(:,iv));
    linshi_W(:,ind_0) = [];
    Z_ini{iv} = linshi_W*max(Z1,Z1')*linshi_W';

    clear Z1 linshi_W
end
clear X X1 ind_0
X = Y;
clear Y


max_iter = 100;
miu = 10;
rho = 1.3;
p = 0.3;%0.2
[Z,F,pre_labels1,obj,R] = TGR(Z_ini,X,Ne,W,lambda1,lambda2,lambda3,miu,rho,max_iter,numClust,truthF,p);
